Bug99 Remote degugger and emulator
==================================

The file bug99.zip should have expanded to the following files and folders:

SourceEdit	Folder containing 1) Customization files for SourceEdit 2) J-F Rossel's cross-assembler package
Bug99.exe	The main debugger application.
inpout32.dll	Third party DLL to allow direct control of the parallel port on any version of Windows.
IdeRam.bin	IDE card RAM. Preloaded with IDEAL 1.2, drives DSK1 2 6 7 8 9 A and B.
Console.zip	Password-protected .zip file. Contains the console ROM and GROMs.
Explorer.zip	Password-protected .zip file. Contains a hard drive-compatible version of MG's Explorer.
GramKarte.zip	Password-protected .zip file. Contains the Mechatronics GramKarte's ROM.
Horizon.zip	Password-protected .zip file. Contains the Horizon Ramdisk DSR RAM and Ramdisk RAM preloaded with freeware.
pCode.zip	Password-protected .zip file. Contains p-code card ROM and GROMs.
RS232.zip	Password-protected .zip file. Contains RS232 card ROM.
Bug99.dsk	Floppy disk image to be transfered on your TI-99/4A. Contains the enslavement routine BUG99/1 in EA5 format.
dsk3.dsk	Floppy disk image containing Funnelweb, DiskU and various freewares. To be installed as DSK3.
dsk5.dsk	Floppy disk image containing my GPL assembler and various utilies. To be installed as DSK5.
dskm.dsk	Floppy disk image containing my Module Explorer GPL debugger. To be installed as DSKM.
Ideal12a.dsk	Floppy disk image containing the DSRs for the IDE card. Different clock versions can be found on my site.
IdeMaster.hdd	Emulated master drive for use with the IDE card. Pre-loaded with several disks of freeware.
bug99.s		Source file (PC txt format). Enslavement routine to run on the TI-99/4A for remote debugging.
Readme.txt	This file.
passwords.txt	Instructions on how to open the password-protected .zip files.
Workspace.wrk	Demo default workspace open upon program startup. You may delete this to start with an empty workspace.

NB The floppy images are already included in the IDE master drive and in the Horizon Ramdisk. The .dsk files are just here as backups.


Installing Bug99
----------------

Copy all the files into a dedicated folder, such as C:\\Program Files\Bug99

Read the file passwords.txt to figure out which .zip files you are allowed to open. Place the files they contain into the same folder as above. You can use Bug99 without any third-party software, but you won't be able to take advantage of the emulated devices for which you don't have ROM image files.

If you wish to use SourceEdit as a program editor, or to use Jean-Francois Rossel's cross-assembler package, see the file SourceEdit.txt in the SourceEdit folder.

To launch Bug99, double-click on Bug99.exe (you may want to create a shortcut for future use). If it crashes upon startup, the most likely cause is a corrupt Workspace.wrk file. Remove it and try again.


Using Bug99
-----------

See the instruction manual on my website http:\\www.nouspikel.com\ti99\bug99.htm

After you run it once, the following files may appear in the application folder. Most of them will be empty.

AmsEeprom.bin		Used by the HAMS version of the AMS memory expansion card, which supports EEPROM chips.
ConsoleEeprom.bin	Used with my console modification overlaying 16K of EEPROM on top of the console ROM.
IdeXram.bin		Used by the IDE card emulation to represent the battery-backed memory of the RTC-65271 clock.
UsbRom.bin		Used by the USB-SM card emulation, to represent the EEPROM chip.
Workspace.wrk		Your workspace settings, saved automatically when you exit the program.
Trace.txt		Log file tracing execution.
Patch.txt		Log file tracing patches.

If you did not open all the password-protected .zip files, the files they contain will be created (but empty) when you run Bug99 for the first time (e.g. ConsoleRom.bin and ConsoleGroms.bin). If you subsequently decide to extract them from a .zip file, just replace the existing files with the extracted ones.

Other files may appear as you manipulate device configuration.





