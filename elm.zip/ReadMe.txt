CONSOLE ROM LOADER
==================

The zip file should have expanded to the following files:

Elm.dsk     a TI-99/4A disk image containig the USB EEPROM manager and loader
readme.txt  this file.

Transfer the files to the TI-99/4A via the parallel cable,
as described on my page: www.nouspikel.com/ti99/download.htm

Then run ELM/1 with an EA5 loader.
Type in DSK1.USBHOST to load the demo DSR.
Try the demo programs in Basic GETDESC, PORTS, INTS, DIRECT.

For details, see my page: www.nouspikel.com/ti99/usb_load.htm

c) Th. Nouspikel  2005
