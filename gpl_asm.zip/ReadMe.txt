========================================================================
       GPL ASSEMBLER/LINKER PACKAGE by Thierry Nouspikel
========================================================================

This ZIP file should have expanded to eight files:

GPL_ASM1.DSK  a floppy disk containing the main programs in the package: assembler, linking loader, etc.
GPL_ASM2.DSK  a floppy disk containing utility programs to be used with this package.
GPL_DOC1.DSK  a floppy disk containing user manuals for the above programs
GPL_DOC2.DSK  ditto
GPL_DOC3.DSK  ditto
GPL_DOC4.DSK  ditto
GPL_DOC5.DSK  ditto
README.TXT    this file

The first 7 files are to be transfered to the TI-99/4A, using the
TI99PIO.EXE program on the PC side and DSK-PC/O on the TI-99/4A side.
These programs can be downloaded from my website at:
http://www.nouspikel.com/ti99/titech.htm
You'll need to build a connection cable between the PC parallel port
and the TI-99/4A RS232 card's PIO port (very easy: see my website for instructions).

How to transfer files
---------------------

1) On the TI-99/4A either enter extended basic (slow)
   or enter Basic with the Editor/Assembler cartridge plugged in.

   Type: CALL INIT
         CALL LOAD("DSKx.DSK-PC/O")
         CALL LINK("FROMPC","DSK1")

   !! Make sure you have a blank floppy in DSK1 !!

2) On the PC, run TI99PIO.EXE
   Use the browse button to select one of the file to transfer
   leave the file type as "program" and press the "Export" button.

3) Wait until transfer is completed, you should see a low of gibberish on
   the top of the TI-99/4A screen.

4) Repeat the procedure for the other files:
   Put a fresh floppy in DSK1 and type again CALL LINK("FROMPC","DSK1").
   On the PC, select another file and click "Export".

   Once done, check that your floppies are ok and now contain files.
   Enjoy it.
					Th.N. 1999
