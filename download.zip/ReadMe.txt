========================================================================
      DOWNLOADER PACKAGE by Thierry Nouspikel
========================================================================

This ZIP file should have expanded to the following files:

TI99PIO.EXE   a Win95 application that handles all communications with the TI-99/4A.
TI99PIO.HLP   a Win95 help file for the above program.
TI99PIO.CNT   a Win95 help contents file for the above program.
FILE-PC.DF80  a DF80 assembly file that transfer any type of file to/from the PC.
PIO.EC        the same program in a format that can be loaded directly through the cable.
DSK-PC.DF80   a DF80 assembly file saves/retrieves floppy disk to/from the PC.
TI2PC.XB      an Extended Basic program that demonstrates communications with TI99PIO.EXE  
README.TXT    this file

The transfer program PIO.EC should first be transfered to the TI-99/4A as
a Dis/Fix 80 file. It can then be used to transfer the other files. 
You only need to do this once, afterwards FILE-PC will be used instead.

You'll need to build a connection cable between the PC parallel port
and the TI-99/4A RS232 card's PIO port (very easy: see my website for instructions).

Alternatively, if you are using PC99, the PC program TI99PIO.EXE can be used to
convert my disk dump files (sector dump) into PC99 format (track dump).



How to transfer these files
---------------------------

1) On the TI-99/4A either enter Extended Basic (slow)
   or enter TI-Basic with the Editor/Assembler cartridge plugged in.

   Type: CALL INIT
         CALL LOAD("PIO.EC")
 
2) On the PC, run TI99PIO.EXE.
   Use the [Browse] button to select PIO.EC as the file to transfer.
   Set the file type as "Dis/Fix" and record length as 80, leave all
   conversion options unchecked and the separator box empty. 
   Click [Export].

3) Wait until transfer is completed and (Extended) Basic returns.
   Then type:
	CALL LINK("FROMPC","DSK1.FILE-PC/O","DF80")

   On the PC, select FILE-PC.DF80 as the file to transfer
   Set the file type as "File dump" then click [Export] again. 
   This will save the transfer program on a floppy disk under the name FILE-PC/O.

4) Repeat the procedure for the other files (always in "File dump" mode). 
   On the TI-99/4A,type:
       CALL LINK("FROMPC","DSK1.DSK-PC/O","DF80")

   On the PC, select the file DSK-PC.DF80 and click [Export].

5) Now transfer the Extended Basic program.
   On the TI-99/4A, type:
      CALL LINK("FROMPC","DSK1.TI2PC","PROG")

   On the PC, select the file TI2PC.XB and click [Export].

6) Once done, check that your floppy is ok and now contains the required files,
   in the proper format:
	DSK-PC/O	Dis/Fix 80
	FILE-PC/O	Dis/Fix 80
	TI2PC		Program

   From now on, you can load FILE-PC/O directly from the floppy, rather than 
   loading PIO.EC from the PC.
   
					Th.N. August 2000
