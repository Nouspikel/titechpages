Hyper-AMS board. Prototype version 1.0.1
========================================

Files generated on 10/31/05 10:05:18
Modified on 26/3/08

Format
------
Gerber RS274X, ASCII Character Set.
Number Format : 4.3, mm, leading zero supression.

Files included:

File Name	Layer Type	Layer Name
---------	----------	-----------
hmem82.g0	Silk Overlay 	Top silk overlay
hmem82.g1	Solder Mask  	Top solder mask
hmem82.g2	Copper       	Top
hmem82.g3	Copper       	Bottom
hmem82.g4	Solder Mask  	Bottom solder mask
hmem82.g5	Assembly     	Board outline


File Name	Layer Pair	Plated\Unplated
---------	----------	---------------
hmem82.drl	Top, Bottom	Plated

T Code	Hole Size	Count
------	---------	-----
T1	0.5mm		215
T2	0.8mm		409
T3	0.9mm		256
T4	1mm		5
T5	2mm		2
T6	3mm		1

File Name
---------
hmem82pins.rtf     Summary of chips pinouts

