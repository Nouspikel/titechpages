RS232 ROM LOADER
================

The zip file should have expanded to the following files:

RS/0.ea5    an EA5 memory image file. Loads the next ones.
RS/1.ea5    continuation of the above. RS232 card ROM.
RS/2.ea5    continuation of the above. Patched version of the DSR
readme.txt  this file.

Transfer the files to the TI-99/4A via the parallel cable,
as described on my page: www.nouspikel.com/ti99/download.htm

Then load and run RS/0 with an EA5 loader. It will copy
RS/1 into the RS232 card ROM space, where you should
have installed an EEPROM. See my page www.nouspikel.com/ti99/eeproms.htm

It will copy RS/2 after toggling bit 7, in case you
are using this bit to swith EEPROM banks. It also pauses to let you 
toggle a switch, if that's how you change pages.

If the copy fails, an error message is displayed and execution aborts.
You can retrieve the faulty address from >A000. The most likely cause
of error is that the EEPROM is still write-protected!

c) Th. Nouspikel  2001
