Low-level access routines for the USB-SM card	

This file should have expended to the following components:

REAME.TXT 	this file
SM.TXT		low-level subroutines for Smartmedia access, in PC text format.
ISP1161.TXT 	low-level subroutines to access the USB host and device controllers.
USBTEST.TXT	demo program making use of the above to test USB communications.
SM_S		same as above, in DV80 format.
ISP1161_S		"
USBTEST_S		"

The last 3 files are sector dumps of DV80 files. They are meant to be transfered to your TI-99/4A via a parallel cable. See my download page for instructions.

c)2004 Th. Nouspikel