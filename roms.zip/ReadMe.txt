CONSOLE ROM LOADER
==================

The zip file should have expanded to the following files:

ROMS/0.ea5    an EA5 memory image file. Loads the next ones.
ROMS/1.ea5    continuation of the above. Console ROM routines.
ROMS/2.ea5    continuation of the above. Placeholder file for future patch.
readme.txt  this file.

Transfer the files to the TI-99/4A via the parallel cable,
as described on my page: www.nouspikel.com/ti99/download.htm

Then load and run ROMS/0 with an EA5 loader. It will copy
ROMS/1 into the console ROM space, where you should
have installed an EEPROM. See my page www.nouspikel.com/ti99/eeproms.htm

It will copy ROMS/2 after toggling bit 17, in case you
are using this bit to swith EEPROM banks. It also pauses to let you 
toggle a switch, if that's how you change pages.
Currently, ROMS/2 is only a placeholder, so ROMS/1 will be used again
in the second page.

If the copy fails, an error message is displayed and execution aborts.
You can retrieve the faulty address from >A000. The most likely cause
of error is that the EEPROM is still write-protected!

c) Th. Nouspikel  2001
