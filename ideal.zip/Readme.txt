This ZIP file contains several versions of IDEAL, the DSRs meant for
my IDE card.

IDEAL10.DSK To be used with my original prototype (non-inverted data bus)
            and with the MESS emulator v083b.

IDEAL11.DSK For the new version of the IDE card (inverted data bus) equiped
            with a RTC-65271 clock chip.

IDEAL12.DSK Ditto, but with a bq4847 clock chip.

IDEAL13.DSK Ditto, buy with either a bq4842 or a bq4852 clock chips.



All .DSK files are 360-sectors floppy disk images, with all sectors in 
numerical order.

The disk of interest should be transfered to your TI-99/4A, for instance with
a parallel cable connection (see my download page for instructions:
www.nouspikel.com/ti99/download.htm ).

Information on how to load the DSRs into the card and operate them can be found
at www.nouspikel.com/ti99/ideal.htm

As always, bug reports and suggestions are welcome.

Enjoy,
			Thierry Nouspikel, July 2004
