========================================================================
      MULTITASKING PACKAGE FOR THE TI-99/4A   by Thierry Nouspikel
========================================================================

This ZIP file should have expanded to five files:

TASKS_1.DSK      a floppy disk containing the (Extended) Basic package.
TASKS_2.DSK      a floppy disk containing most of the assembly package.
TASKS_3.DSK      a floppy disk containing the GPL package (+1 assembly file).
MULTITASKING.DOC the reference manual in Winword format.
README.TXT       this file

The disk files should be transfered to the TI-99/4A, using the
TI99PIO.EXE program on the PC side and DSK-PC/O on the TI-99/4A side.
These programs can be freely downloaded from my website at:
http://www.nouspikel.com/ti99/download.htm
You'll need to build a connection cable between the PC parallel port
and the TI-99/4A RS232 card's PIO port (very easy: see my website for instructions).
Alternatively, TI99PIO.EXE can convert the .DSK files in a PC99 compatible format.

Reference manual
----------------
The reference manual can also be accessed on-line at:
http://www.nouspikel.com/ti99/tasks.htm

How to transfer files
---------------------
1) On the TI-99/4A either enter Extended Basic (slow)
   or enter TI-Basic with the Editor/Assembler cartridge plugged in.

   Type: CALL INIT
         CALL LOAD("DSKx.DSK-PC/O")
         CALL LINK("FROMPC","DSK1")

   !! Make sure you have a blank floppy in DSK1 !!

2) On the PC, run TI99PIO.EXE
   Use the "Browse" button to select the TASKS_1.DSK file
   Set the file type as "Disk dump" and click the "Export" button.

3) Wait until transfer is completed: you should see a low of gibberish on
   the upper part of the TI-99/4A screen.

4) Insert a fresh floppy in DSK1 and repeat the operation with TASKS_2.DSK

5) Ditto for TASKS_3.DSK
 
Once done, check that your floppies are ok and now contain the files described
in the webpage/manual.


To convert the disk into PC-99 format
-------------------------------------
1) On the PC, run TI99PIO.EXE
   In the edit box, enter the name of the desired PC99 disk file.
   Set the file type as "Disk dump" and check "Add track format (PC99)".
    
2) Click the "Convert" button (previously named "Export").
   Use the Browse button in the new dialog box to select TASKS_1.DSK
   Click "OK" to convert.

3) Repeat for TASKS_2 and TASKS_3.

I'm not sure how the multitasker performs on PC99, but this technique may
usefull to transfer the files to the TI-99/4A via a serial cable for instance.

Enjoy!
					Th.N. 2001
