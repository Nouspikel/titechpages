USB-SmartMedia card. Version 1.2. c) July 2003, Th. Nouspikel
====================

The ZIP file should have expended to the following files:

File Name	Layer Type	Layer Name
---------	----------	-----------
usb7.g0		Silk Overlay 	Top silk overlay
usb7.g1		Solder Mask  	Top solder mask
usb7.g2		Copper       	Top
usb7.g3		Copper       	Bottom
usb7.g4		Solder Mask  	Bottom solder mask
usb7.g5		Assembly     	Board outline (18 corners)
usb7.drl	NC Drill	Plated holes

File formats
------------
Gerber RS274X, ASCII Character Set.
NC Drill: Excellon format.
Number Format : 4.3, mm, leading zero supression.

Drill tool list
---------------
T Code	Hole Size	Count
------	---------	-----
T1	0.5mm		509
T2	0.7mm		6
T3	0.8mm		16
T4	1mm		2
T5	1.1mm		2
T6	1.4mm		4
T7	91mil		7


