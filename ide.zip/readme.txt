IDE INTERFACE CARD for the TI-99/4A
===================================

The file IDE.ZIP should have expanded to:

IDE6.SCH     The schematics file, in PC-trace format.

2PAD35.DEF   Several definition files for the footprints of
DIP14W3.DEF  the various components. Use these to create 
DIP16W3.DEF  your own PCB layout.
DIP20W3.DEF        "
DIP28W6.DEF        "
DIP32W6.DEF        "
SIP3.DEF           "
TO92.DEF           "
IDE.DEF            "
PEBUS.DEF          "

README.TXT   This file

PC-Trace can be downloaded freely from www.eesoft.com
However, to print out either the schematics or a PCB layout
you will have to pay a registration fee...

