VDM99 Virtual Disk Manager for the TI-99/4A
===========================================

This package contains a PC application that enables you to manage drives on a TI-99/4A connected to the PC via a serial or parallel cable, or disk-image files residing on your PC.

The file VDM99.ZIP should have expanded to the following files:

VDM99.EXE 		The application itself
inpout32.dll		A third party DLL used to control the parallel port
VDM99.DSK		A disk image containing hook routines and source code
HookPIO.DF80		Hook routine for the PIO port
HookRS1.DF80		Hook routine for the parallel port
emulators.txt		Instructions for people writing emulators
ReadMe.txt		This file
vdm99.htm		The instruction manual, in the form of a HTML document

Notes:

1)  inpout32.dll is a third party software that allows a program to control the parallel port directly, in spite of Windows paranoid restrictions. To my knowledge, it is free and virus-free, but I cannot take responsability for it...

2) HookPIO.DF80 and HookRS1.DF80 are used to transfer the disk VDM99.DSK to your TI-99/4A the very first time. They are included on the disk itself, together with the routines hooking the other ports.


Installing VDM99
----------------
Copy the above files into a dedicated folder. 
Launch VDM99.EXE.

For help, see vdm99.htm or the VDM99 webpage at http:\\www.nouspikel.com\ti99\vdm99.htm


Enjoy!

	Th.N. March 2011