#ifndef CONFIG_H
#define CONFIG_H

@TOP@

/* Base IO address for parallel port */
#undef IOPORT

/* Define to use ECP config register */
#undef USE_ECP

/* Define if D0-D7 are connected "backwards" */
#undef DATABUS_REVERSED

@BOTTOM@

#endif
