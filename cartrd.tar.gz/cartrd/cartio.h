extern void cio_setup();
void cio_setgromaddr(int addr);
int cio_getgromaddr();
unsigned char cio_getgrombyte();
int cio_probegrom(int addr);
