#include "config.h"
#include "cartio.h"

#include <stdio.h>
#include <unistd.h>


extern int optind;
extern char *optarg;

int lo_addr, hi_addr;

void do_probe()
{
  int i, a;

  lo_addr = 0xffff;
  hi_addr = 0;

  fprintf(stderr, "Probing: [        ]\b\b\b\b\b\b\b\b\b");
  fflush(stderr);
  for(i=0; i<8; i++)
    if(cio_probegrom(a = i<<13)) {
      putc('#', stderr);
      fflush(stderr);
      if(a < lo_addr)
	lo_addr = a;
      a += 0x1fff;
      if(a > hi_addr)
	hi_addr = a;
    } else {
      putc('.', stderr);
      fflush(stderr);
    }
  if(lo_addr > hi_addr)
    fprintf(stderr, "\nNo GROM:s found!\n");
  else
    fprintf(stderr, "\n Low address = %04x\nHigh address = %04x\n",
	    lo_addr, hi_addr);
}

int main(int argc, char *argv[])
{
  int c, addr_set = 0, eight_k_per_bank = 0;
  FILE *f = stdout;

  cio_setup();
#ifdef HAVE_SETUID
  setuid(getuid());
#endif

  while((c=getopt(argc, argv, "h8a:"))!=EOF)
    switch(c) {
     case 'h':
       fprintf(stderr, "Usage: %s [-h] [-8] [-a lowaddr,highaddr] [gromfile]\n",
	       argv[0]);
       return 0;
     case '8':
       eight_k_per_bank = 1;
       break;
     case 'a':
       if(2 == sscanf(optarg, "%x,%x", &lo_addr, &hi_addr)) {
	 addr_set++;
	 break;
       } else {
	 fprintf(stderr, "Illegal -a option\n");
	 return 1;
       }
    }
  if(optind<argc)
    if((f=fopen(argv[optind], "wb"))==NULL) {
      fprintf(stderr, "Failed to open \"%s\" for output.\n", argv[optind]);
      return 1;
    }

  if(!addr_set)
    do_probe();

  cio_setgromaddr(lo_addr);
  while(lo_addr <= hi_addr) {
    int n = cio_getgrombyte();
    if((lo_addr & 0x1800) == 0x1800 && !eight_k_per_bank)
      n = 0xff;
    putc(n, f);
    lo_addr++;
  }

  if(f != stdout)
    fclose(f);
  return 0;
}
