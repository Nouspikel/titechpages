extern void w_lpdata(unsigned char n);
extern void w_lpcontrol(unsigned char n);
extern unsigned char r_lpstatus();
extern unsigned char r_lpdata();
extern void ll_usleep(int n);
extern unsigned int ll_millitm();
extern void ll_setup();
