#include "config.h"
#include "ll.h"

#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/sysi86.h>
#include <sys/psw.h>

#define LPDATA (IOPORT)
#define LPSTATUS (IOPORT+1)
#define LPCONTROL (IOPORT+2)

void w_lpdata(unsigned char n)
{
  /* Write D0-D7 */
  asm("outb (%%dx)" : : "a" (n), "d" (LPDATA));
}

unsigned char r_lpdata()
{
  /* Read D0-D7 */
  unsigned char r;
  asm("inb (%%dx)" : "=a" (r) : "d" (LPDATA));
  return r;
}

void w_lpcontrol(unsigned char n)
{
  /* Write control */
  asm("outb (%%dx)" : : "a" (n), "d" (LPCONTROL));
}

unsigned char r_lpstatus()
{
  /* Read status */
  unsigned char r;
  asm("inb (%%dx)" : "=a" (r) : "d" (LPSTATUS));
  return r;
}

void ll_usleep(int n)
{
  hrtime_t end = gethrtime()+n*1000;
  while(gethrtime()<end);
}

unsigned int ll_millitm()
{
  return (unsigned int)(gethrtime()/1000000);
}

void ll_setup()
{
  if (sysi86(SI86V86, V86SC_IOPL, PS_IOPL) < 0) {
    fprintf(stderr, "Failed to set IOPL for I/O, make sure program is setuid root.\n");
    exit(1);
  }
#ifdef USE_ECP
  asm("outb (%%dx)" : : "a" (1<<5), "d" (IOPORT+0x402));
#endif
}
