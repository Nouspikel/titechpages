#include <stdio.h>

#include "config.h"
#include "cartio.h"

#define C_STROBE   1
#define C_AUTOFEED 2
#define C_INIT     4
#define C_SELECT   8
#define S_ERROR    8
#define S_SELIN    16
#define S_PAPEROUT 32
#define S_ACK      64
#define S_BUSY     128

#define C_DIR      32

#define NOT_GR    S_BUSY
#define NOT_DBIN  C_AUTOFEED
#define MO        C_INIT
#define GS        C_SELECT

#define TIMEOUT 100

#ifdef DATABUS_REVERSED
#define REVERSE(x) (reverse_tab[x])
static unsigned char reverse_tab[256];
#else
#define REVERSE(x) (x)
#endif

void cio_leave()
{
  /* release GS */
  /* release DBIN */

  w_lpcontrol(NOT_DBIN|C_DIR);
  w_lpcontrol(NOT_DBIN);
}

void cio_setup()
{
#ifdef DATABUS_REVERSED
  int i;
  for(i=0; i<256; i++) {
    int n=0, j;
    for(j=0; j<8; j++)
      n|=((i>>j)&1)<<(7-j);
    reverse_tab[i] = n;
  }
#endif

  ll_setup();
  w_lpcontrol(NOT_DBIN);
  atexit(cio_leave);
}

static void cio_gromtimeout()
{
  w_lpcontrol(NOT_DBIN|C_DIR);
  fprintf(stderr, "*** Timeout accessing GROM\n");
  w_lpcontrol(NOT_DBIN);
  exit(1);
}

static unsigned char cio_gromcycle(int ctrl)
{
  unsigned int t = ll_millitm();
  unsigned char res;
  w_lpcontrol(ctrl);
  while(!(r_lpstatus() & NOT_GR))
    if(((unsigned int)(ll_millitm()-t))>TIMEOUT)
      cio_gromtimeout();
  w_lpcontrol(ctrl|GS);
  t = ll_millitm();
  while(r_lpstatus() & NOT_GR)
    if(((unsigned int)(ll_millitm()-t))>TIMEOUT)
      cio_gromtimeout();
  res = r_lpdata();
  w_lpcontrol(ctrl);
  return REVERSE(res);
}

static void cio_gromwrite(unsigned char v, int mo)
{
  int ctrl = (mo? NOT_DBIN|MO : NOT_DBIN);
  w_lpdata(REVERSE(v));
  cio_gromcycle(ctrl);
}

static unsigned char cio_gromread(unsigned char v, int mo)
{
  int ctrl = (mo? C_DIR|MO : C_DIR);
  w_lpdata(v);
  return cio_gromcycle(ctrl);
}

void cio_setgromaddr(int addr)
{
  cio_gromwrite((addr >> 8)&0xff, 1);
  cio_gromwrite(addr&0xff, 1);
}

int cio_getgromaddr()
{
  int addr = cio_gromread(0xff, 1)<<8;
  addr |= cio_gromread(0xff, 1);
  return (addr-1)&0xffff;
}

unsigned char cio_getgrombyte()
{
  return cio_gromread(0xff, 0);
}

int cio_probegrom(int addr)
{
  unsigned char buf[16];
  static unsigned char testpattern[] = { 0x00, 0x55, 0xaa, 0xcc };
  int i, b;
  cio_setgromaddr(addr);
  for(b=0; b<16; b++)
    buf[b] = cio_gromread(0xff, 0);
  for(i=0; i<4; i++) {
    cio_setgromaddr(addr);
    for(b=0; b<16; b++)
      if(buf[b] != cio_gromread(testpattern[i], 0))
	return 0;
  }
  return 1;
}
