#include "config.h"
#include "ll.h"

#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <asm/io.h>
#include <unistd.h>

#define LPDATA (IOPORT)
#define LPSTATUS (IOPORT+1)
#define LPCONTROL (IOPORT+2)

void w_lpdata(unsigned char n)
{
  /* Write D0-D7 */
  asm("outb (%%dx)" : : "a" (n), "d" (LPDATA));
}

unsigned char r_lpdata()
{
  /* Read D0-D7 */
  unsigned char r;
  asm("inb (%%dx)" : "=a" (r) : "d" (LPDATA));
  return r;
}

void w_lpcontrol(unsigned char n)
{
  /* Write control */
  asm("outb (%%dx)" : : "a" (n), "d" (LPCONTROL));
}

unsigned char r_lpstatus()
{
  /* Read status */
  unsigned char r;
  asm("inb (%%dx)" : "=a" (r) : "d" (LPSTATUS));
  return r;
}

void ll_usleep(int n)
{
  for(n; n > 0; n--)
    inb(80);
}

unsigned int ll_millitm()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return (unsigned int)(tv.tv_sec*1000+tv.tv_usec/1000);
}

void ll_setup()
{
  if (ioperm((IOPORT), 3, 1) || ioperm(80, 1, 1)) {
    fprintf(stderr, "Failed to set IOPL for I/O, make sure program is setuid root.\n");
    exit(1);
  }
#ifdef USE_ECP
  if(iopl(3)) {
    perror("iopl");
    exit(1);
  }
  asm("outb (%%dx)" : : "a" (1<<5), "d" (IOPORT+0x402));
  if(iopl(0)) {
    perror("iopl");
    exit(1);
  }
#endif
}
