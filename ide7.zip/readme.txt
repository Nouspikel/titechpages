Generated on 07/14/04 14:02:20

Format
------
Gerber RS274X, ASCII Character Set.
Number Format : 4.3, mm, leading zero supression.
Drill Format: Excellon, ASCII Character Set 4.3, mm, leading 0 supr.


Files Generated:

File Name	Layer Type	Layer Name
---------	----------	-----------
ide7.g0	Silk Overlay 	Top silk overlay
ide7.g1	Solder Mask  	Top solder mask
ide7.g2	Copper       	Top
ide7.g3	Copper       	Bottom
ide7.g4	Solder Mask  	Bottom solder mask
ide7.g5	Assembly     	Board outline
ide7.drl Drill		Drill, all holes plated


Tool list:

T Code	Hole Size	Count
------	---------	-----
T1	0.5mm		554
T2	0.7mm		4
T3	0.8mm		134
T4	1mm		42
T5	1.2mm		2
T6	1.4mm		2
T7	91mil		1