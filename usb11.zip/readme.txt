USB-SM board, version 1.5
=========================
(c) 2003 Th. Nouspikel

USB11 version, generated on 11/04/03 16:11:54

Format
======
Drill file: Excellon format, ASCII character set.
All other files: Gerber RS274X format, ASCII character set.

Number Format : 4.3, mm, leading zero supression.


Files included:
===============
File Name	Layer Type	Layer Name
---------	----------	-----------
usb11.drl	Top, Bottom	Drill file
usb11.g0	Silk Overlay 	Top silk screen
usb11.g1	Solder Mask  	Top solder mask
usb11.g2	Copper       	Top copper
usb11.g3	Copper       	Bottom copper
usb11.g4	Solder Mask  	Bottom solder mask
usb11.g5	Assembly     	Board outline (18 corners)

