========================================================================
       PC-JOYSTICKS ADAPTER  by Thierry Nouspikel
========================================================================

This ZIP file should have expanded to two files:

PCJOYP.DSK    a floppy disk that contains instructions on how to build an
              adapter for PC-joysticks, a TI-artist schematic, and several
              application programs. The content of the disk is listed in
              the !READ-ME file on the disk.
README.TXT    this file

The first file is to be transfered to the TI-99/4A, using the
TI99PIO.EXE program on the PC side and DSK-PC/O on the TI-99/4A side.
These programs can be downloaded from my website at:
http://www.nouspikel.com/ti99/titech.htm
You'll need to build a connection cable between the PC parallel port
and the TI-99/4A RS232 card's PIO port (very easy: see my website for instructions).

How to transfer files
---------------------

1) On the TI-99/4A either enter extended basic (slow)
   or enter Basic with the Editor/Assembler cartridge plugged in.

   Type: CALL INIT
         CALL LOAD("DSKx.DSK-PC/O")
         CALL LINK("FROMPC","DSK1")

   !! Make sure you have a blank floppy in DSK1 !!

2) On the PC, run TI99PIO.EXE
   Use the browse button to select RIP.DSK
   leave the file type as "program" and press the "Export" button.

3) Wait until transfer is completed, you should see a low of gibberish on
   the top of the TI-99/4A screen.

   Once done, check that your floppy is ok and now contains the above files.
   Enjoy it.
					Th.N. 1999
